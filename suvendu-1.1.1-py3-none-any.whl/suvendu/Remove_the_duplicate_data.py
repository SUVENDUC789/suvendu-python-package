# Remove the duplicate data from the list and print the list
def Remove_the_duplicate_data_from_the_list(a):
    b=set(a)
    b=list(b)
    return b
